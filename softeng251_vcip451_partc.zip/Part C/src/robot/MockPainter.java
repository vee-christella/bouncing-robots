package robot;

import java.awt.Color;
import java.awt.Image;
import java.awt.image.ImageObserver;

/**
 * Implementation of the Painter interface that does not actually do any
 * painting. A MockPainter implementation responds to Painter requests by
 * logging simply logging them. The contents of a MockPainter object's
 * log can be retrieved by a call to toString() on the MockPainter.
 * 
 * @author Craig Sutherland
 * 
 */
public class MockPainter implements Painter {
	// Internal log.
	private StringBuffer _log = new StringBuffer();

	/**
	 * Returns the contents of this MockPainter's log.
	 */
	public String toString() {
		return _log.toString();
	}

	/**
	 * Logs the drawRect call.
	 */
	public void drawRect(int x, int y, int width, int height) {
		_log.append("(rectangle " + x + "," + y + "," + width + "," + height + ")");
	}

	/**
	 * Logs the drawOval call.
	 */
	public void drawOval(int x, int y, int width, int height) {
		_log.append("(oval " + x + "," + y + "," + width + "," + height + ")");
	}

	/**
	 * Logs the drawLine call.
	 */
	public void drawLine(int x1, int y1, int x2, int y2) {
		_log.append("(line " + x1 + "," + y1 + "," + x2 + "," + y2 + ")");
	}

	/**
	 * Logs the drawHexagon call.
	 */
	public void drawHexagon(int x1, int y1, int width, int height) {
		_log.append("(hexagon " + x1 + "," + y1 + "," + width + "," + height + ")");
		_log.append("(from " + (x1 + 20) + "," + y1 + " to " + (x1 + width-20) + "," + y1 + ")");
		_log.append("(from " + (x1 + width- 20) + "," + y1 + " to " + (x1 + width) + "," + (y1 + height/2) + ")");
		_log.append("(from " + (x1 + width) + "," + (y1 + height/2) + " to " + (x1 + width- 20) + "," + (y1 + height) + ")");
		_log.append("(from " + (x1 + width-20) + "," + (y1 + height) + " to " + (x1 + 20) + "," + (y1 + height) + ")");
		_log.append("(from " + (x1 + 20) + "," + (y1 + height) + " to " + x1 + "," + (y1 + height/2) + ")");
		_log.append("(from " + x1 + "," + (y1 + height/2) + " to " + (x1 + 20) + "," + y1 + ")");


	}

	/**
	 * Logs the drawDiamond call.
	 */
	public void drawDiamond(int x1, int y1, int width, int height) {
		_log.append("(diamond " + x1 + "," + y1 + "," + width + "," + height + ")");
		_log.append("(from " + (x1 + width/2) + "," + y1 + " to " + (x1 + width) + "," + (y1 + height/2) + ")");
		_log.append("(from " + (x1 + width) + "," + (y1 + height/2) + " to " + (x1 + width/2) + "," + (y1 + height) + ")");
		_log.append("(from " + (x1 + width/2) + "," + (y1 + height) + " to " + x1 + "," + (y1 + height/2) + ")");
		_log.append("(from " + x1 + "," + (y1 + height/2) + " to " + (x1 + width/2) + "," + y1 + ")");


	}

	/**
	 * Logs the setColour call.
	 */
	public void setColour(Color color) {
		_log.append("(set colour to " + color + ")");
	}

	/**
	 * Logs the getColour call.
	 */
	public void getColour() {
		_log.append("(obtained colour)");
	}

	/**
	 * Logs the drawDiamond call.
	 */
	public void fillRect(int x1, int y1, int width, int height) {
		_log.append("(filled rectangle " + x1 + "," + y1 + "," + width + "," + height + ")");
	}

	/**
	 * Logs the drawImage call.
	 */
	public void drawImage(Image img, int x1, int y1, int width, int height) {
		_log.append("(image drawn)");
	}

	
	/**
	 * Logs the translate call.
	 */
	public void translate(int x, int y) {
		
	}
	
	/**
	 * Logs the drawCentredText call.
	 */
	public void drawCentredText(String text, Robot robot) {
		_log.append("(string drawn)");
	}

}




