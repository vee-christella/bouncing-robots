package robot;

import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

/** Class to represent a flying robot
 * 
 * @author Vanessa Ciputra
 * 
 */


public class ImagedRobot extends Robot {



	private Image _img;

	/** Create an instance of the robot using the default constructor  with
	 * variables that are set to default values of the Robot class
	 */
	public ImagedRobot() {
		super();
	}

	/** Create an instance of the robot with the specified image using the default constructor with
	 * variables that are set to default values of the Robot class
	 */
	public ImagedRobot(String imgPath) {
		super();
		readImage(imgPath);
	}

	/**
	 * Creates ImagedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 */
	public ImagedRobot(int x, int y) {
		super(x, y);
	}

	/**
	 * Creates ImagedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param imgPath the path of the specified image
	 */
	public ImagedRobot(int x, int y, String imgPath) {
		super(x, y);
		readImage(imgPath);
	}



	/**
	 * Creates ImagedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed and direction for horizontal axis.
	 * @param deltaY speed and direction for vertical axis.
	 */
	public ImagedRobot(int x, int y, int deltaX, int deltaY) {
		super(x, y, deltaX, deltaY);
	}


	/**
	 * Creates ImagedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed and direction for horizontal axis.
	 * @param deltaY speed and direction for vertical axis.
	 * @param imgPath the path of the specified image
	 */
	public ImagedRobot(int x, int y, int deltaX, int deltaY, String imgPath) {
		super(x, y, deltaX, deltaY);
		readImage(imgPath);

	}



	/**
	 * Creates a ImagedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed (pixels per move call) and direction for horizontal 
	 *        axis.
	 * @param deltaY speed (pixels per move call) and direction for vertical 
	 *        axis.
	 * @param width width in pixels.
	 * @param height height in pixels.
	 */
	public ImagedRobot(int x, int y, int deltaX, int deltaY, int width, int height) {
		super(x, y, deltaX, deltaY, width, height);
	}
	
	/**
	 * Creates a ImagedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed (pixels per move call) and direction for horizontal 
	 *        axis.
	 * @param deltaY speed (pixels per move call) and direction for vertical 
	 *        axis.
	 * @param width width in pixels.
	 * @param height height in pixels.
	 * @param text the text to be added to the robot
	 */
	public ImagedRobot(int x, int y, int deltaX, int deltaY, int width, int height, String text) {
		super(x,y,deltaX,deltaY,width,height);
		this.addText(text);
		
	}

	/**
	 * Creates a ImagedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed (pixels per move call) and direction for horizontal 
	 *        axis.
	 * @param deltaY speed (pixels per move call) and direction for vertical 
	 *        axis.
	 * @param width width in pixels.
	 * @param height height in pixels.
	 * @param text the text to be added to the robot
	 * @param imgPath the path of the specified image
	 */
	public ImagedRobot(int x, int y, int deltaX, int deltaY, int width, int height, String text, String imgPath) {
		super(x, y, deltaX, deltaY, width, height);
		readImage(imgPath);
		this.addText(text);
	}



	/**
	 * Detects the path of the image to be drawn and attempts to read the file. 
	 * An exception will be thrown if the file cannot be found. If the reader works,
	 * the the image is passed to be read.
	 */
	public void readImage(String imgPath) {
		try {
			// Read the image path to import image
			_img = ImageIO.read(new File(imgPath));
		} catch (IOException e) {

			// If file cannot be found, print error message
			System.out.println("Image could not be read");

		}



		//_img = Toolkit.getDefaultToolkit().createImage(imgPath);
	}



	/**
	 * Creates the ImagedRobot using the specified image path.
	 */
	protected void doPaint(Painter painter) {
		painter.drawImage(_img, _x, _y, _width, _height);

	}

}



