package robot;

import java.awt.Color;

/** Class to represent a tracked robot
 * 
 * @author Vanessa Ciputra
 * 
 */

public class DynamicWheeledRobot extends Robot {

	private Color _colour = Color.black;
	private boolean check = false;
	private int _speedX = 0;
	private int _speedY = 0;


	/** Create an instance of the robot using the default constructor  with
	 * variables that are set to default values of the Robot class
	 */
	public DynamicWheeledRobot() {
		super();
	}


	/**
	 * Creates TrackedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 */
	public DynamicWheeledRobot(int x, int y) {
		super(x, y);
	}

	/**
	 * Creates TrackedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param c colour being initialised.
	 * 
	 */
	public DynamicWheeledRobot(int x, int y, Color c) {
		super(x, y);
		_colour = c;
	}


	/**
	 * Creates TrackedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed and direction for horizontal axis.
	 * @param deltaY speed and direction for vertical axis.
	 */
	public DynamicWheeledRobot(int x, int y, int deltaX, int deltaY) {
		super(x, y, deltaX, deltaY);
	}

	/**
	 * Creates TrackedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed and direction for horizontal axis.
	 * @param deltaY speed and direction for vertical axis.
	 * @param c colour being initialised.
	 */
	public DynamicWheeledRobot(int x, int y, int deltaX, int deltaY, Color c) {
		super(x, y, deltaX, deltaY);
		_colour = c;
	}


	/**
	 * Creates a TrackedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed (pixels per move call) and direction for horizontal 
	 *        axis.
	 * @param deltaY speed (pixels per move call) and direction for vertical 
	 *        axis.
	 * @param width width in pixels.
	 * @param height height in pixels.
	 */
	public DynamicWheeledRobot(int x, int y, int deltaX, int deltaY, int width, int height) {
		super(x, y, deltaX, deltaY, width, height);
	}


	/**
	 * Creates a TrackedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed (pixels per move call) and direction for horizontal 
	 *        axis.
	 * @param deltaY speed (pixels per move call) and direction for vertical 
	 *        axis.
	 * @param width width in pixels.
	 * @param height height in pixels.
	 */
	public DynamicWheeledRobot(int x, int y, int deltaX, int deltaY, int width, int height, Color c) {
		super(x, y, deltaX, deltaY, width, height);
		_colour = c;
	}
	
	/**
	 * Creates a DynamicWheeledRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed (pixels per move call) and direction for horizontal 
	 *        axis.
	 * @param deltaY speed (pixels per move call) and direction for vertical 
	 *        axis.
	 * @param width width in pixels.
	 * @param height height in pixels.
	 * @param text the text to be added to the robot
	 */
	public DynamicWheeledRobot(int x, int y, int deltaX, int deltaY, int width, int height, String text) {
		super(x,y,deltaX,deltaY,width,height);
		this.addText(text);
		
	}
	
	/**
	 * Creates a DynamicWheeledRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed (pixels per move call) and direction for horizontal 
	 *        axis.
	 * @param deltaY speed (pixels per move call) and direction for vertical 
	 *        axis.
	 * @param width width in pixels.
	 * @param height height in pixels.
	 * @param text the text to be added to the robot
	 * @param c the colour to be painted
	 */
	public DynamicWheeledRobot(int x, int y, int deltaX, int deltaY, int width, int height, String text, Color c) {
		super(x,y,deltaX,deltaY,width,height);
		_colour = c;
		this.addText(text);
		
	}



	/**
	 * Paints the current TrackedRobot object using the supplied Painter object 
	 * in a shape of a rectangle. The colour of the rectangle is given at construction - if no
	 * colour has been specified, keep to black.
	 */

	protected void doPaint(Painter painter) {

		// If the left or right wall has been bounced off, fill the rectangle
		if (check == true) {
			// Initialise the colour of the shape which has been set during construction of
			// object
			painter.setColour(_colour);
			painter.getColour();

			// Draw the rectangle outline in the colour chosen
			painter.drawRect(_x,_y,_width,_height);

			painter.fillRect(_x, _y, _width, _height);
			painter.setColour(Color.BLACK);
			
		} else {
			// Initialise the colour of the shape which has been set during construction of
			// object
			//painter.setColour(Color.BLACK);
			painter.getColour();

			// Draw the rectangle outline in the colour chosen
			painter.drawRect(_x,_y,_width,_height);


		}

		// Fill the rectangle if the left or right wall has been bounced off
		if (_deltaX == (-_speedX) || _x == 0) {
			painter.fillRect(_x, _y, _width, _height);
			check = true;
			painter.setColour(Color.BLACK);
			// Otherwise, draw the outline and revert to WheeledRobot's structure
		} else if (_deltaY == (-_speedY) || _y == 0) {
			painter.drawRect(_x,_y,_width,_height);
			check = false;
			painter.setColour(Color.BLACK);
		} 

		// Set the current velocity to be used in the next run through
		_speedX = _deltaX;
		_speedY = _deltaY;


	}
}








