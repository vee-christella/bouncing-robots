package robot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Abstract superclass to represent the general concept of a Robot. This class
 * defines state common to all special kinds of Robot instances and implements
 * a common movement algorithm. Robot subclasses must override method paint()
 * to handle robot-specific painting.
 * 
 * @author Craig Sutherland
 * 
 */
public abstract class Robot {
	// === Constants for default values. ===
	protected static final int DEFAULT_X_POS = 0;

	protected static final int DEFAULT_Y_POS = 0;

	protected static final int DEFAULT_DELTA_X = 5;

	protected static final int DEFAULT_DELTA_Y = 5;

	protected static final int DEFAULT_HEIGHT = 35;

	protected static final int DEFAULT_WIDTH = 25;
	// ===

	// === Instance variables, accessible by subclasses.
	protected int _x;

	protected int _y;

	protected int _deltaX;

	protected int _deltaY;

	protected int _width;

	protected int _height;

	protected CarrierRobot _parent;
	
	protected String _text;

	// ===

	/**
	 * Creates a Robot object with default values for instance variables.
	 */
	public Robot() {
		this(DEFAULT_X_POS, DEFAULT_Y_POS, DEFAULT_DELTA_X, DEFAULT_DELTA_Y, DEFAULT_WIDTH, DEFAULT_HEIGHT);
	}

	/**
	 * Creates a Robot object with a specified x and y position.
	 */
	public Robot(int x, int y) {
		this(x, y, DEFAULT_DELTA_X, DEFAULT_DELTA_Y, DEFAULT_WIDTH, DEFAULT_HEIGHT);
	}

	/**
	 * Creates a Robot instance with specified x, y, deltaX and deltaY values.
	 * The Robot object is created with a default width and height.
	 */
	public Robot(int x, int y, int deltaX, int deltaY) {
		this(x, y, deltaX, deltaY, DEFAULT_WIDTH, DEFAULT_HEIGHT);
	}

	/**
	 * Creates a Robot instance with specified x, y, deltaX, deltaY, width and
	 * height values.
	 */
	public Robot(int x, int y, int deltaX, int deltaY, int width, int height) {
		_x = x;
		_y = y;
		_deltaX = deltaX;
		_deltaY = deltaY;
		_width = width;
		_height = height;
	}

	/**
	 * Moves this Robot object within the specified bounds. On hitting a 
	 * boundary the Robot instance bounces off and back into the two- 
	 * dimensional world. 
	 * @param width width of two-dimensional world.
	 * @param height height of two-dimensional world.
	 */
	public void move(int width, int height) {
		int nextX = _x + _deltaX;
		int nextY = _y + _deltaY;

		if (nextX <= 0) {
			nextX = 0;
			_deltaX = -_deltaX;
		} else if (nextX + _width >= width) {
			nextX = width - _width;
			_deltaX = -_deltaX;
		}

		if (nextY <= 0) {
			nextY = 0;
			_deltaY = -_deltaY;
		} else if (nextY + _height >= height) {
			nextY = height - _height;
			_deltaY = -_deltaY;
		}

		_x = nextX;
		_y = nextY;
	}

	/**
	 * Method to be implemented by concrete subclasses to handle subclass
	 * specific painting.
	 * @param painter the Painter object used for drawing.
	 */
	protected abstract void doPaint(Painter painter);

	/**
	 * Returns this Robot object's x position.
	 */
	public int x() {
		return _x;
	}

	/**
	 * Returns this Robot object's y position.
	 */
	public int y() {
		return _y;
	}

	/**
	 * Returns this Robot object's speed and direction.
	 */
	public int deltaX() {
		return _deltaX;
	}

	/**
	 * Returns this Robot object's speed and direction.
	 */
	public int deltaY() {
		return _deltaY;
	}

	/**
	 * Returns this Robot's width.
	 */
	public int width() {
		return _width;
	}

	/**
	 * Returns this Robot's height.
	 */
	public int height() {
		return _height;
	}
	
	/**
	 * Returns this Robot's colour.
	 */
	public String text() {
		return _text;
		}
	
	
	/**
	 * Returns a String whose value is the fully qualified name of this class 
	 * of object. E.g., when called on a WheeledRobot instance, this method 
	 * will return "robot.WheeledRobot".
	 */
	public String toString() {
		return getClass().getName();
	}


	/**
	 * Set the parent of the current robot
	 */
	public void setParent(CarrierRobot robot) {
		_parent = robot;
	}

	/**
	 * Returns the CarrierRobot that contains the Robot that method parent
	 * is called on. If the callee object is not a child within a 
	 * CarrierRobot instance this method returns a null
	 */
	public CarrierRobot parent() {

		// If a parent exists for the callee, return the parent class 
		if (_parent != null) {
			return _parent;
		} else {
			return null;
		}

	}


	/**
	 * Returns an ordered list of Robot objects. The first item within the
	 * list is the root CarrierRobot of the containment hierarchy.
	 * The last item within the list is the callee object (hence this method
	 * always returns a list with at least one item). Any intermediate
	 * items are CarrierRobots that connect the root CarrierRobot to 
	 * the callee Robot. Eg. given:
	 * 
	 * CarrierRobot root = new CarrierRobot();
	 * CarrierRobot intermediate = new CarrierRobot();
	 * Robot flying = new FlyingRobot();
	 * root.add(intermediate);
	 * intermediate.add(flying);
	 * 
	 * a call to flying.path() yields: [root, intermediate, flying]
	 * 
	 */
	public List<Robot> path() {
		
		// Initalise a temporary array to store the parents 
		Robot _temp = this;
		
		// Initalise list of the path 
		List<Robot> _paths = new ArrayList<Robot>();

		// Add to the list the current object until the last object is found
		while (_temp.parent() != null) {
			_paths.add(_temp);
			_temp = _temp.parent();
		}
		
		_paths.add(_temp);

		// Reverse the order so the root is at the beginning of the list
		Collections.reverse(_paths);

		//System.out.println(_paths);
		return _paths;
	}
	
	/**
	 * Initialises a particular string of text to be included in the robot
	 * @param text
	 */
	public void addText(String text) {
		_text = text;
	}

	/** 
	 * Template method used to ensure that the paint method is always called,
	 * especially if text has been initialised.
	 * @param painter
	 */
	public final void paint(Painter painter) {
		if (_text != null) {
			this.doPaint(painter);
			painter.drawCentredText(_text, this);
		} else {
			this.doPaint(painter);
		}
		
	}
	
	
	
	


}
