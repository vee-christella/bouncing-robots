package robot.views;

import java.util.ArrayList;
import java.util.List;

import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import robot.CarrierRobot;
import robot.Robot;
import robot.RobotModel;

/**
 * Class to implement requirements and specifications for Task1.
 * 
 * @author Vanessa Ciputra
 * 
 */

public class Task1 implements TreeModel {
	
	protected RobotModel _adaptee;
	protected CarrierRobot _parent;
	
	// List of RobotModelListeners.
	protected List<TreeModelListener> _listeners;
	
	/** Create constructor to insert the RobotModel as adaptee
	 * @param model
	 */
	public Task1(RobotModel model) {
		// Assign RobotModel as the adaptee of this class
		_adaptee = model;
		_listeners = new ArrayList<TreeModelListener>(); 
	}
	
	/** Returns the root of the tree. Returns null only if the tree has no nodes.
	 * 
	 */
	public Object getRoot() {
		// Obtain the root of the adaptee through this method
		_parent = _adaptee.root();
		return _parent;
	}
	
	
	/** Returns the child of parent at index index in the parent's child array.
	 *  parent must be a node previously obtained from this data source. 
	 *  This should not return null if index is a valid index for parent 
	 *  (that is index >= 0 && index < getChildCount(parent)).
	 */
	public Object getChild(Object parent, int index) {
		Object child = null;
		
		// Ensure that the parent specified is a carrier robot, otherwise return null for failure
		if (parent instanceof CarrierRobot) {
			
			// Check that the index is in the bounds of the list of children of the parent
			if (index < ((CarrierRobot)parent).robotCount() && index >= 0) {
				child = ((CarrierRobot) parent).robotAt(index);
			} else {
				System.out.println("Index out of bounds");
			}
			
		}
		
		// Return the child of the specified index if successful, otherwise output null
		return child;
	}
	
	/** Returns the number of children of parent. Returns 0 if the
	 *  node is a leaf or if it has no children. parent must be a
	 *  node previously obtained from this data source.
	 *   
	 */
	public int getChildCount(Object parent) {
		int count = 0; 
		
		// Ensure that the parent is a carrierRobot and not a node
		if (parent instanceof CarrierRobot) {
			
			// Obtain the number of children of the specified parent
			count = ((CarrierRobot) parent).robotCount();
		}
		
		return count;
	}

	
	/**Returns true if node is a leaf. It is possible for this 
	 * method to return false even if node has no children. A 
	 * directory in a filesystem, for example, may contain no files;
	 * the node representing the directory is not a leaf, but it
	 * also has no children.
	 */
	public boolean isLeaf(Object node) {
		boolean check = false;
		
		// Check if the node is a CarrierRobot that is empty - despite 
		// having no parents, this is still not a leaf and therefore must return false
		if (node instanceof CarrierRobot) {
			if (((CarrierRobot) node).robotCount() == 0) {
				check = false;
			}
			
		// If the node is a child and possesses a parent, return true
		} else if (node instanceof Robot) {
			if (((Robot) node).parent() != null) {
				check = true;
			}
		}
		
		return check;
	}
	
	/** Left as a empty method body as does not correlate to class
	 */
	public void valueForPathChanged(TreePath path, Object newValue) {
		
	}
	
	
	/** Returns the index of child in parent. If either parent or 
	 *  child is null, returns -1. If either parent or child don't
	 *  belong to this tree model, returns -1.
	 */
	public int getIndexOfChild(Object parent, Object child) {
		int index = -1;
		
		// Ensure that the parent is a CarrierRobot and the child is a node
		if (parent instanceof CarrierRobot && child instanceof Robot) {
			
			// Find the index number of the child in the specified parent
			index = ((CarrierRobot) parent).indexOf((Robot) child);
		}
		
		return index;
	}
	
	
	/** Adds a listener for the TreeModelEvent posted after the 
	 * tree changes.
	 */
	public void addTreeModelListener(TreeModelListener l) {
		_listeners.add(l);
	}
	
	/** 
	 * Removes a listener previously added with addTreeModelListener.
	 */
	public void removeTreeModelListener(TreeModelListener l) {
		int index = -1;
		
		// Ensure that there exists a TreeModelListener in the current list of listeners
		for (int i = 0; i < _listeners.size(); i++) {
			if (_listeners.get(i) == l) {
				index = i;
			}
		}
		
		// If l does not exist, output an error message
		if (index == -1) {
			System.out.println("There is no matching TreeModelListener that can be removed in this TreeModel");
		} else {
			// Otherwise, remove the specified listener with the index found previously
			_listeners.remove(index);
		}
		
//		_listeners.remove(l);
		
	}
}
