package robot.views;

import java.util.ArrayList;
import java.util.List;

import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import robot.Robot;
import robot.RobotModel;
import robot.RobotModelEvent;
import robot.RobotModelListener;

/**
 * Class to implement requirements and specifications for Task1.
 * 
 * @author Vanessa Ciputra
 * 
 */

public class Task2 extends Task1 implements RobotModelListener {


	public Task2(RobotModel model) {
		super(model);
	}

	@Override
	public void update(RobotModelEvent event) {
		
		// Extract the initial parameters from the RobotModelEvent
		// to construct the TreeModelEVent for notification 
		RobotModel source = event.source();
		int[] childIndices = new int[1];
		childIndices[0] = event.index();
		Robot[] children = new Robot[1];
		children[0] = event.operand();
		Object[] path;


		// Ensure that the parent of the RobotModel exists
		try {
			List<Robot> pathList = event.parent().path();
			 path = pathList.toArray();
			
			// If the event type being fired is of RobotAdded, notify every listener 
			// to update the Tree
			if (event.eventType().equals(event.eventType().RobotAdded)) {

				for (TreeModelListener treeListener: _listeners) {
					TreeModelEvent treeEvent = new TreeModelEvent(source, path, childIndices, children);
					treeListener.treeNodesInserted(treeEvent);
				}
				
			// If the event type being fired is of RobotRemoved, notify every listener 
			// to update the Tree
			} else if (event.eventType().equals(event.eventType().RobotRemoved)) {

				for (TreeModelListener treeListener: _listeners) {
					TreeModelEvent treeEvent = new TreeModelEvent(source, path, childIndices, children);
					treeListener.treeNodesRemoved(treeEvent);
				}
			}

			// If the parent does not exist, catch the NullPointerException to handle
			// the case and initialise path to be null 
		} catch (NullPointerException e) {
			
			path = null;

			// If the event type being fired is of RobotAdded, notify every listener 
			// to update the Tree
			if (event.eventType().equals(event.eventType().RobotAdded)) {

				for (TreeModelListener treeListener: _listeners) {
					TreeModelEvent treeEvent = new TreeModelEvent(source, path, childIndices, children);
					treeListener.treeNodesInserted(treeEvent);
				}
				
			// If the event type being fired is of RobotRemoved, notify every listener 
			// to update the Tree
			} else if (event.eventType().equals(event.eventType().RobotRemoved)) {

				for (TreeModelListener treeListener: _listeners) {
					TreeModelEvent treeEvent = new TreeModelEvent(source, path, childIndices, children);
					treeListener.treeNodesRemoved(treeEvent);
				}
			}
		}




	}
}
