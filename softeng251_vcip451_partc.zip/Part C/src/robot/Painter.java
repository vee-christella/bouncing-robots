package robot;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.image.ImageObserver;

/** 
 * Interface to represent a type that offers primitive drawing methods.
 * 
 * @author Craig Sutherland
 * 
 */
public interface Painter {
	/**
	 * Draws a rectangle. Parameters x and y specify the top left corner of the
	 * oval. Parameters width and height specify its width and height.
	 */
	public void drawRect(int x, int y, int width, int height);
	
	/**
	 * Draws an oval. Parameters x and y specify the top left corner of the
	 * oval. Parameters width and height specify its width and height.
	 */
	public void drawOval(int x, int y, int width, int height);
	
	/**
	 * Draws a line. Parameters x1 and y1 specify the starting point of the 
	 * line, parameters x2 and y2 the ending point.
	 */
	public void drawLine(int x1, int y1, int x2, int y2);
	
	/**
	 * Draws a hexagon. Parameters x1 and y1 specify the top left corner of
	 * the hexagon. Parameters width and height specify its width and height.
	 */
	public void drawHexagon(int x1, int y1, int width, int height);
	
	/**
	 * Draws a diamond like shape. Parameters x1 and y1 specify the top left corner of
	 * the hexagon. Parameters width and height specify its width and height.
	 */
	public void drawDiamond(int x1, int y1, int width, int height);
	
	/**
	 * Sets the colour of the object to be used
	 */
	public void setColour(Color color);
	
	/**
	 * Returns a string of the colour of the object to be used
	 */
	public void getColour();
	
	/**
	 * Fills the object's rectangular shape with a particular colour. Parameters
	 * x1 and y1 specify the top left corner of the shape. Parameters width and height
	 * specify the rectangle's width and height. These act as bounds for the shape to 
	 * be filled.
	 */
	public void fillRect(int x1, int y1, int width, int height);
	
	/**
	 * Draws an image with the specified coordinates as the bounding box as well
	 * as the width and height of the image.
	 */
	public void drawImage(Image img, int x1, int y1, int width, int height);
	
	/**
	 * Translates the coordinate system to new coordinates
	 */
	public void translate(int x, int y);
	
	/**
	 * Draws text, ensuring that the text is centred
	 */
	public void drawCentredText(String text, Robot robot);
	

	
	
}


