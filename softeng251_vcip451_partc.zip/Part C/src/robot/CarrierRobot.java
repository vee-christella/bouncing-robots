package robot;


import java.util.ArrayList;
import java.util.List;

/** Class to represent a tracked robot
 * 
 * @author Vanessa Ciputra
 * 
 */


public class CarrierRobot extends Robot {


	private List<Robot> _childRobots= new ArrayList<Robot>();

	/** 
	 * Creates a CarrierRobot object with default values for state
	 */
	public CarrierRobot() {
		super();
	}

	/**S
	 * Creates a CarrierRobot object with specified location values.
	 * default values for other state items
	 * @param x x position.
	 * @param y y position.
	 */
	public CarrierRobot(int x, int y) {
		super(x, y);
	}

	/**
	 * Creates a CarrierRobot with specified values for location, 
	 * velocity and direction. Non-specified state items take on 
	 * default values.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed and direction for horizontal axis.
	 * @param deltaY speed and direction for vertical axis.
	 */
	public CarrierRobot(int x, int y, int deltaX, int deltaY) {
		super(x, y, deltaX, deltaY);
	}

	/**
	 * Creates a CarrierRobot with specified values for location,
	 * velocity, direction, width and height.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed (pixels per move call) and direction for horizontal 
	 *        axis.
	 * @param deltaY speed (pixels per move call) and direction for vertical 
	 *        axis.
	 * @param width width in pixels.
	 * @param height height in pixels.
	 */
	public CarrierRobot(int x, int y, int deltaX, int deltaY, int width, int height) {
		super(x, y, deltaX, deltaY, width, height);
	}


	/**
	 * Creates a CarrierRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed (pixels per move call) and direction for horizontal 
	 *        axis.
	 * @param deltaY speed (pixels per move call) and direction for vertical 
	 *        axis.
	 * @param width width in pixels.
	 * @param height height in pixels.
	 * @param text the text to be added to the robot
	 */
	public CarrierRobot(int x, int y, int deltaX, int deltaY, int width, int height, String text) {
		super(x,y,deltaX,deltaY,width,height);
		this.addText(text);
		
	}


	/** Moves a CarrierRobot object (including its children) within the
	 * bounds specified by arguments width and height.
	 * @param width width in pixels.
	 * @param height height in pixels.
	 */
	public void move(int width, int height) {
		super.move(width, height);

		// Move each child robot in the carrier robot using
		// the bounds of the carrier robot
		for (int i = 0; i < _childRobots.size(); i++) {
			_childRobots.get(i).move(_width, _height);
		}



	}

	/**
	 * Paints a CarrierRobot object by drawing a rectangle around the 
	 * edge of its bounding box. The CarrierRobot object's children are
	 * then painted.
	 */
	protected void doPaint(Painter painter) {
		// Paint the carrier robot
		painter.drawRect(_x, _y, _width, _height);

		// Change the coordinate system of the child robots to be the dimensions
		// of the bounding box
		painter.translate(_x, _y);



		// Paint the child robots 
		for (int i = 0; i < _childRobots.size(); i++) {
			_childRobots.get(i).paint(painter);
		}

		painter.translate(-_x, -_y);

	}


	/** 
	 * Attempts to add a Robot to a CarrierRobot object. If successful, a
	 * two-way link is established between the CarrierRobot and the newly added Robot.
	 * Note that this method has package visibility - for reasons
	 * that will become apparent in Robot III.
	 * @param robot the robot to be added.
	 * @throws IllegalArgumentException if an attempt is made to add a Robot
	 * to a CarrierRobot instance where the Robot argument is already a child
	 * within a CarrierRobot instance. An IllegalArgumentException is also thrown 
	 * when an attempt is made to add a Robot that will not fit within the bounds
	 * of the proposed CarrierRobot object.
	 */
	void add(Robot robot) throws IllegalArgumentException {

		// Check if the child robot to be place exceeds the bounds of the carrier robot
		// If the robot does not exceed, add to carrier robot
		if ((robot.width() + robot.x()) < (_width) && ((robot.height() + robot.y()) < (_height)) && robot.parent() == null) {
			_childRobots.add(robot);
			robot.setParent(this);

			// If the robot is already part of another carrier, throw exception
		} else if (robot.parent() != null) {
			throw new IllegalArgumentException("Robot is already a child of another CarrierRobot.");

			// If the robot exceed dimensions, throw exception
		} else {
			throw new IllegalArgumentException("Robot exceeds CarrierRobot dimensions.");
		}



	}

	/**
	 * Removes a particular Robot from a CarrierRobot instance. Once removed,
	 * the two-way link between the CarrierRobot and its former child is
	 * destroyed. This method has no effect if the Robot specified to remove
	 * is not a child of the CarrierRobot. Note that this method has package 
	 * visibility - for reasons that will become apparent in Robot III.
	 * @param robot the robot to be removed
	 */
	void remove(Robot robot) {

		for (int i = 0; i < _childRobots.size(); i++) {

			// If the index matches, remove the two way link between the child and carrier robot
			if (_childRobots.get(i) == robot) {
				_childRobots.remove(i);
				robot.setParent(null);
				return;
			}


		}
	}


	/** 
	 * Returns the Robot at a specified position within a CarrierRobot. If
	 * the position specified is less than zero or greater than the number of
	 * children stored in the CarrierRobot less one this method throws an 
	 * IndexOutOfBoundsException.
	 * @param index the specified index position.
	 */
	public Robot robotAt(int index) throws IndexOutOfBoundsException {
		if (index < 0 || index > _childRobots.size()) {
			throw new IndexOutOfBoundsException("Index is out of bounds.");
		} else {
			return _childRobots.get(index);
		}
	}


	/** 
	 * Returns the number of children contained within a CarrierRobot object.
	 * Note this method is not recursive - it simply returns the number of
	 * children at the top level within the callee CarrierRobot object.
	 */
	public int robotCount() {
		return _childRobots.size();
	}

	/**
	 * Returns the index of a specified child within a CarrierRobot object.
	 * If the Robot specified is not actually a child of the CarrierRobot
	 * this method returns -1; otherwise the value returned is in the range
	 * 0 .. robotCount() - 1.
	 * @param the robot whose index position within the CarrierRobot is
	 * requested.
	 */
	public int indexOf(Robot robot) {
		if (_childRobots.contains(robot)) {
			return _childRobots.indexOf(robot);
		} else {
			return -1;
		}

	}

	/**
	 * Returns true if the Robot argument is a child of the CarrierRobot 
	 * object on which this method is called, false otherwise.
	 */
	public boolean contains(Robot robot) {
		return _childRobots.contains(robot);

	}

}
