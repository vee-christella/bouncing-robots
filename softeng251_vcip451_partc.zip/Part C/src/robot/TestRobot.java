package robot;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;


/**
 * A class that implements test cases aimed at identifying bugs in the 
 * implementations of classes Robot and WheeledRobot.
 * 
 * @author Craig Sutherland
 * 
 */
public class TestRobot {
	// Fixture object that is used by the tests.
	private MockPainter _painter;

	/**
	 * This method is called automatically by the JUnit test-runner immediately
	 * before each @Test method is executed. setUp() recreates the fixture so 
	 * that there no side effects from running individual tests.
	 */
	@Before
	public void setUp() {
		_painter = new MockPainter();
	}

	/**
	 * Test to perform a simple (non-bouncing) movement, and to ensure that a
	 * Robot's position after the movement is correct.
	 */
	@Test
	public void testSimpleMove() {
		WheeledRobot robot = new WheeledRobot(100, 20, 12, 15);
		robot.paint(_painter);
		robot.move(500, 500);
		robot.paint(_painter);
		assertEquals("(rectangle 100,20,25,35)(rectangle 112,35,25,35)", 
				_painter.toString());
	}
	
	/**
	 * Test to perform a bounce movement off the right-most boundary and to
	 * ensure that the Robot's position after the movement is correct.
	 */
	@Test
	public void testRobotMoveWithBounceOffRight() {
		WheeledRobot robot = new WheeledRobot(100, 20, 12, 15);
		robot.paint(_painter);
		robot.move(135, 10000);
		robot.paint(_painter);
		robot.move(135, 10000);
		robot.paint(_painter);
		assertEquals("(rectangle 100,20,25,35)(rectangle 110,35,25,35)"
				+ "(rectangle 98,50,25,35)", _painter.toString());
	}

	/**
	 * Test to perform a bounce movement off the left-most boundary and to
	 * ensure that the Robot's position after the movement is correct.
	 */
	@Test
	public void testRobotMoveWithBounceOffLeft() {
		WheeledRobot robot = new WheeledRobot(10, 20, -12, 15);
		robot.paint(_painter);
		robot.move(10000, 10000);
		robot.paint(_painter);
		robot.move(10000, 10000);
		robot.paint(_painter);
		assertEquals("(rectangle 10,20,25,35)(rectangle 0,35,25,35)"
				+ "(rectangle 12,50,25,35)", _painter.toString());
	}

	/**
	 * Test to perform a bounce movement off the bottom right corner and to
	 * ensure that the Robot's position after the movement is correct.
	 */
	@Test
	public void testRobotMoveWithBounceOffBottomAndRight() {
		WheeledRobot robot = new WheeledRobot(10, 90, -12, 15);
		robot.paint(_painter);
		robot.move(125, 135);
		robot.paint(_painter);
		robot.move(125, 135);
		robot.paint(_painter);
		assertEquals("(rectangle 10,90,25,35)(rectangle 0,100,25,35)"
				+ "(rectangle 12,85,25,35)", _painter.toString());
	}
	
	/** 
	 * Test to ensure that an oval is drawn to represent a FlyingRobot
	 * object has painted itself correctly
	 */
	@Test
	public void testShape() {
		FlyingRobot robot = new FlyingRobot(10, 90, 25, 30, 30, 40);
		robot.paint(_painter);
		assertEquals("(oval 10,90,30,40)", _painter.toString());
	}
	
	/**
	 * Test to ensure that a hexagon is drawn to represent a LARGE TrackedRobot
	 * object has painted itself correctly. Also ensure that if the dimensions
	 * of the hexagon is too small, a 4-sided diamond shape is printed instead.
	 * This is dictated by changing the width of the tracked robot.
	 */
	@Test
	public void testTrackedBigShape() {
		// Test the possibility where the robot is large - width of the Tracked Robot is greater than 40
		TrackedRobot robot = new TrackedRobot(10, 90, 25, 30, 65, 45);
		robot.paint(_painter);
		assertEquals("(hexagon 10,90,65,45)(from 30,90 to 55,90)(from 55,90 to 75,112)"
				+ "(from 75,112 to 55,135)(from 55,135 to 30,135)(from 30,135 to 10,112)(from 10,112 to 30,90)"
				,_painter.toString());
	}

	/**
	 * Test to ensure that a diamond is drawn to represent a SMALL TrackedRobot
	 * object has painted itself correctly. 
	 * This is dictated by changing the width of the tracked robot to be less than 40.
	 */
	@Test
	public void testTrackedSmallShape() {
		// Test the possibility where the robot is small - width of the Tracked Robot is smaller than 40
		TrackedRobot robot = new TrackedRobot(10, 90, 25, 30, 20, 45);
		robot.paint(_painter);
		assertEquals("(diamond 10,90,20,45)(from 20,90 to 30,112)(from 30,112 to 20,135)"
				+ "(from 20,135 to 10,112)(from 10,112 to 20,90)", _painter.toString());
	}
	
	
	/**
	 * Test to ensure that a diamond is drawn to represent a SMALL TrackedRobot
	 * object has painted itself correctly. 
	 * This is dictated by changing the width of the tracked robot to be less than 40.
	 */
	
	/*
	@Test
	public void DynamicWheeledRobotBounceOffTop() {
		// Test the possibility where the robot is small - width of the Tracked Robot is smaller than 40
		TrackedRobot robot = new TrackedRobot(10, 90, 25, 30, 20, 45);
		robot.paint(_painter);
		assertEquals("(diamond 10,90,20,45)(from 20,90 to 30,112)(from 30,112 to 20,135)"
				+ "(from 20,135 to 10,112)(from 10,112 to 20,90)", _painter.toString());
	}
	
	*/
	
	

	
}
