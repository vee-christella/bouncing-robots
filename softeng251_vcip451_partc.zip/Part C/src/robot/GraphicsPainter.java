package robot;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;

/**
 * Implementation of the Painter interface that delegates drawing to a
 * java.awt.Graphics object.
 * 
 * @author Craig Sutherland
 * 
 */
public class GraphicsPainter implements Painter {
	// Delegate object.
	private Graphics _g;

	/**
	 * Creates a GraphicsPainter object and sets its Graphics delegate.
	 */
	public GraphicsPainter(Graphics g) {
		this._g = g;
	}

	/**
	 * @see robot.Painter.drawRect
	 */
	public void drawRect(int x, int y, int width, int height) {
		_g.drawRect(x, y, width, height);
	}

	/**
	 * @see robot.Painter.drawOval
	 */
	public void drawOval(int x, int y, int width, int height) {
		_g.drawOval(x, y, width, height);
	}

	/**
	 * @see bounce.Painter.drawLine.
	 */
	public void drawLine(int x1, int y1, int x2, int y2) {
		_g.drawLine(x1, y1, x2, y2);
	}

	/**
	 * @see robot.Painter.drawHexagon
	 */
	public void drawHexagon(int x1, int y1, int width, int height) {
		// Start from the top left corner of the shape and draw in a clockwise direction
		// In this case, start from the top left vertex 
		_g.drawLine(x1 + 20, y1, x1 + width-20, y1);
		_g.drawLine(x1 + width- 20, y1, x1 + width, y1 + height/2);
		_g.drawLine(x1 + width, y1 + height/2, x1 + width- 20, y1 + height);
		_g.drawLine(x1 + width-20, y1 + height, x1 + 20, y1 + height);
		_g.drawLine(x1 + 20, y1 + height, x1, y1 + height/2);
		_g.drawLine(x1, y1 + height/2, x1 + 20, y1);
	}


	/**
	 * @see robot.Painter.drawHexagon
	 */
	public void drawDiamond(int x1, int y1, int width, int height) {

		// Start from the top left corner of the shape and draw in a clockwise direction
		// In this case, start from the top vertex 
		_g.drawLine(x1 + width/2, y1, x1 + width, y1 + height/2);
		_g.drawLine(x1 + width, y1 + height/2, x1 + width/2, y1 + height);
		_g.drawLine(x1 + width/2, y1 + height, x1, y1 + height/2);
		_g.drawLine(x1, y1 + height/2, x1 + width/2, y1);
	}



	/**
	 * @see robot.painter.setColour
	 */
	public void setColour(Color color) {
		_g.setColor(color);
	}

	/**
	 * @see robot.painter.getColour
	 */
	public void getColour() {
		_g.getColor();
	}


	/**
	 * @see robot.painter.fillRect
	 */
	public void fillRect(int x1, int y1, int width, int height) {
		this.getColour();
		_g.fillRect(x1, y1, width, height);
	}


	/**
	 * @see robot.Painter.drawImage
	 */
	public void drawImage(Image img, int x, int y, int width, int height) {
		_g.drawImage(img, x, y, width, height, null);
	}


	/**
	 * @see robot.Painter.translate
	 */
	public void translate(int x, int y) {
		_g.translate(x, y);
	}


	/**
	 * @see robot.Painter.drawCentredText
	 */
	public void drawCentredText(String text, Robot robot) {
		
		// Obtain font metric information
		FontMetrics metrics = _g.getFontMetrics();
		
		// Calculate the top line of the text as well as the bottom line of the text
		int ascent = metrics.getAscent();
		int descent = metrics.getDescent();
		
		// Find the middle of the text placement
		int x = robot.x() + (robot.width() - metrics.stringWidth(text))/2;
		int y = robot.y() + (robot.height() - metrics.getHeight()) / 2 + ascent/2;
		
		// Adjust text heights accordingly if the ascent is not equal to the descent
		if (ascent > descent) {
			y = y + (ascent - descent)/2;
		} else if (descent > ascent) {
			y = y + (descent - ascent)/2;
		}
		
		_g.drawString(text, x, y);

	}


}
