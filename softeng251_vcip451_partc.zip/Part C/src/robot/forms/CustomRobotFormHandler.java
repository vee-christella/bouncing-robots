package robot.forms;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutionException;

import javax.imageio.ImageIO;
import javax.swing.SwingWorker;

import robot.CarrierRobot;
import robot.CustomRobot;
import robot.RobotModel;
import robot.forms.util.Form;
import robot.forms.util.FormHandler;

/**
 * Loads and scales the image provided using a background thread and 
 * makes the new CustomRobot instance available to the Event Dispatch
 * thread.
 * 
 * @author Vanessa Ciputra
 * 
 */

public class CustomRobotFormHandler implements FormHandler {

	private RobotModel _model;
	private CarrierRobot _parentOfNewRobot;
	private File _imageFile;
	private int _width;
	private int _deltaX;
	private int _deltaY;
	private int _height;
	private CustomSwingWorker _customSwingWorker;
	

	/**
	 * Creates a CustomRobotFormHandler.
	 * 
	 * @param model the RobotModel to which the handler should add a newly 
	 *        constructed CustomRobot object. 
	 * @param parent the CarrierRobot object that will serve as the parent for
	 *        a new CustomRobot instance.
	 */
	public CustomRobotFormHandler(RobotModel model, CarrierRobot parent) {
		_model = model;
		_parentOfNewRobot = parent;
	}


	private class CustomSwingWorker extends SwingWorker<BufferedImage, Void> {

		@Override
		protected BufferedImage doInBackground() throws Exception {
			// TODO Auto-generated method stub


			// Load the original image (ImageIO.read() is a blocking call).
			BufferedImage fullImage = null;
			try {
				fullImage = ImageIO.read(_imageFile);
			} catch(IOException e) {
				System.out.println("Error loading image.");
			}

			int fullImageWidth = fullImage.getWidth();
			int fullImageHeight = fullImage.getHeight();

			BufferedImage scaledImage = fullImage;

			// Scale the image if necessary.
			if(fullImageWidth > _width) {
				double scaleFactor = (double)_width / (double)fullImageWidth;
				_height = (int)((double)fullImageHeight * scaleFactor);

				scaledImage = new BufferedImage(_width,_height,BufferedImage.TYPE_INT_RGB);
				

				Graphics2D g = scaledImage.createGraphics();

				// Method drawImage() scales an already loaded image. The 
				// ImageObserver argument is null because we don't need to monitor 
				// the scaling operation.
				g.drawImage(fullImage, 0, 0, _width, _height, null);
				return scaledImage;
			}
			
			return scaledImage;
	
		}


		protected void done() {


			// Create the new Robot and add it to the model.
			BufferedImage imageOut;
			
			// Ensure that the creation of the robot is successful
			try {
				imageOut = get();
				CustomRobot imageRobot = new CustomRobot(_deltaX, _deltaY, imageOut);
				_model.add(imageRobot, _parentOfNewRobot);
				
				// Catch an exception if the calling thread is interrupted 
				// during a call to the blocking method
			} catch (InterruptedException e) {
				e.printStackTrace();
				// Catch and handle the exception in case the execution
				// of a task has failed
			} catch (ExecutionException e) {
				e.printStackTrace();
			}
			


		}

	}


	@Override
	public void processForm(Form form) {
		// TODO Auto-generated method stub

		// Read field values from the form.
		File imageFile = (File)form.getFieldValue(File.class, ImageFormElement.IMAGE);
		_imageFile = imageFile;
		int width = form.getFieldValue(Integer.class, RobotFormElement.WIDTH);
		_width = width;
		int deltaX = form.getFieldValue(Integer.class, RobotFormElement.DELTA_X);
		_deltaX = deltaX;
		int deltaY = form.getFieldValue(Integer.class, RobotFormElement.DELTA_Y);
		_deltaY = deltaY;

		long startTime = System.currentTimeMillis();

		_customSwingWorker = new CustomSwingWorker();
		_customSwingWorker.execute();







		long elapsedTime = System.currentTimeMillis() - startTime;
		System.out.println("Image loading and scaling took " + elapsedTime + "ms.");
	}

}
