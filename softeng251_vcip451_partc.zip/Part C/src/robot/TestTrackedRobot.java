package robot;


import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;


/**
 * A class that implements test cases aimed at identifying bugs in the 
 * implementations of classes Robot and WheeledRobot.
 * 
 * @author Vanessa Ciputra
 * 
 */

public class TestTrackedRobot {

	// Fixture object that is used by the tests.
	private MockPainter _painter;

	/**
	 * This method is called automatically by the JUnit test-runner immediately
	 * before each @Test method is executed. setUp() recreates the fixture so 
	 * that there no side effects from running individual tests.
	 */
	@Before
	public void setUp() {
		_painter = new MockPainter();
	}


	/**
	 * Test to ensure that a hexagon is drawn to represent a TrackedRobot
	 * object has painted itself correctly. Also ensure that if the dimensions
	 * of the hexagon is too small, a 4-sided diamond shape is printed instead.
	 * This is dictated by changing the width of the tracked robot.
	 */
	@Test
	public void testBigShape() {
		// Test two possibilities of the tracked robot where one is big and one is small
		// Two different shapes should be drawn due
		TrackedRobot robot = new TrackedRobot(10, 90, 25, 30, 65, 45);
		robot.paint(_painter);
		assertEquals("(hexagon 10,90,65,45)(from 30,90 to 55,90)(from 55,90 to 75,112)"
				+ "(from 75,112 to 55,135)(from 55,135 to 30,135)"
				+ "(from 30,135 to 10,112)(from 10,112 to 30,90)",_painter.toString());
	}

	/**
	 * Test to ensure that a diamond is drawn to represent a SMALL TrackedRobot
	 * object has painted itself correctly. 
	 * This is dictated by changing the width of the tracked robot to be less than 40.
	 */
	@Test
	public void testSmallShape() {
		TrackedRobot robot = new TrackedRobot(10, 90, 25, 30, 20, 45);
		robot.paint(_painter);
		assertEquals("(diamond 10,90,20,45)(from 20,90 to 30,112)(from 30,112 to 20,135)"
				+ "(from 20,135 to 10,112)(from 10,112 to 20,90)", _painter.toString());
	}


	/**
	 * Test to perform a simple (non-bouncing) movement, and to ensure that a
	 * Robot's position after the movement is correct.
	 */
	@Test
	public void testSimpleMove() {
		TrackedRobot robot = new TrackedRobot(100, 20, 12, 15);
		robot.paint(_painter);
		robot.move(500, 500);
		robot.paint(_painter);
		assertEquals("(diamond 100,20,25,35)(from 112,20 to 125,37)(from 125,37 to 112,55)"
				+ "(from 112,55 to 100,37)(from 100,37 to 112,20)(diamond 112,35,25,35)"
				+ "(from 124,35 to 137,52)(from 137,52 to 124,70)(from 124,70 to 112,52)"
				+ "(from 112,52 to 124,35)", _painter.toString());
	}

	/**
	 * Test to perform a bounce movement off the right-most boundary and to
	 * ensure that the Robot's position after the movement is correct.
	 */
	@Test
	public void testRobotMoveWithBounceOffRight() {
		TrackedRobot robot = new TrackedRobot(100, 20, 12, 15);
		robot.paint(_painter);
		robot.move(135, 10000);
		robot.paint(_painter);
		robot.move(135, 10000);
		robot.paint(_painter);
		assertEquals("(diamond 100,20,25,35)(from 112,20 to 125,37)(from 125,37 to 112,55)"
				+ "(from 112,55 to 100,37)(from 100,37 to 112,20)(diamond 110,35,25,35)"
				+ "(from 122,35 to 135,52)(from 135,52 to 122,70)(from 122,70 to 110,52)"
				+ "(from 110,52 to 122,35)(diamond 98,50,25,35)(from 110,50 to 123,67)"
				+ "(from 123,67 to 110,85)(from 110,85 to 98,67)(from 98,67 to 110,50)", _painter.toString());
	}

	/**
	 * Test to perform a bounce movement off the left-most boundary and to
	 * ensure that the Robot's position after the movement is correct.
	 */
	@Test
	public void testRobotMoveWithBounceOffLeft() {
		TrackedRobot robot = new TrackedRobot(10, 20, -12, 15);
		robot.paint(_painter);
		robot.move(10000, 10000);
		robot.paint(_painter);
		robot.move(10000, 10000);
		robot.paint(_painter);
		assertEquals("(diamond 10,20,25,35)(from 22,20 to 35,37)(from 35,37 to 22,55)"
				+ "(from 22,55 to 10,37)(from 10,37 to 22,20)(diamond 0,35,25,35)(from 12,35 to 25,52)"
				+ "(from 25,52 to 12,70)(from 12,70 to 0,52)(from 0,52 to 12,35)(diamond 12,50,25,35)"
				+ "(from 24,50 to 37,67)(from 37,67 to 24,85)(from 24,85 to 12,67)(from 12,67 to 24,50)", _painter.toString());
	}

	/**
	 * Test to perform a bounce movement off the bottom right corner and to
	 * ensure that the Robot's position after the movement is correct.
	 */
	@Test
	public void testRobotMoveWithBounceOffBottomAndRight() {
		TrackedRobot robot = new TrackedRobot(10, 90, -12, 15);
		robot.paint(_painter);
		robot.move(125, 135);
		robot.paint(_painter);
		robot.move(125, 135);
		robot.paint(_painter);
		assertEquals("(diamond 10,90,25,35)(from 22,90 to 35,107)(from 35,107 to 22,125)(from 22,125 to 10,107)"
				+ "(from 10,107 to 22,90)(diamond 0,100,25,35)(from 12,100 to 25,117)(from 25,117 to 12,135)"
				+ "(from 12,135 to 0,117)(from 0,117 to 12,100)(diamond 12,85,25,35)(from 24,85 to 37,102)"
				+ "(from 37,102 to 24,120)(from 24,120 to 12,102)(from 12,102 to 24,85)", _painter.toString());
	}


}
