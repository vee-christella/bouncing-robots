package robot;

/** Class to represent a tracked robot
 * 
 * @author Vanessa Ciputra
 * 
 */

public class TrackedRobot extends Robot {


	/** Create an instance of the robot using the default constructor  with
	 * variables that are set to default values of the Robot class
	 */
	public TrackedRobot() {
		super();
	}


	/**
	 * Creates TrackedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 */
	public TrackedRobot(int x, int y) {
		super(x, y);
	}


	/**
	 * Creates TrackedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed and direction for horizontal axis.
	 * @param deltaY speed and direction for vertical axis.
	 */
	public TrackedRobot(int x, int y, int deltaX, int deltaY) {
		super(x, y, deltaX, deltaY);
	}


	/**
	 * Creates a TrackedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed (pixels per move call) and direction for horizontal 
	 *        axis.
	 * @param deltaY speed (pixels per move call) and direction for vertical 
	 *        axis.
	 * @param width width in pixels.
	 * @param height height in pixels.
	 */
	public TrackedRobot(int x, int y, int deltaX, int deltaY, int width, int height) {
		super(x, y, deltaX, deltaY, width, height);
	}
	
	/**
	 * Creates a TrackedRobot instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed (pixels per move call) and direction for horizontal 
	 *        axis.
	 * @param deltaY speed (pixels per move call) and direction for vertical 
	 *        axis.
	 * @param width width in pixels.
	 * @param height height in pixels.
	 * @param text the text to be added to the robot
	 */
	public TrackedRobot(int x, int y, int deltaX, int deltaY, int width, int height, String text) {
		super(x,y,deltaX,deltaY,width,height);
		this.addText(text);
		
	}

	

	/**
	 * Paints the current TrackedRobot object using the supplied Painter object 
	 * in a shape of a hexagon. If dimensions are too small, then a four-sided
	 * diamond shape is drawn.
	 */
	protected void doPaint(Painter painter) {
		// If dimensions of the hexagon are 'too small', draw a four sided diamond
		// shape instead
		if (_width < 40) {
			painter.drawDiamond(_x, _y, _width, _height);
		} else { 
			painter.drawHexagon(_x, _y, _width, _height);
		}

	}

}



