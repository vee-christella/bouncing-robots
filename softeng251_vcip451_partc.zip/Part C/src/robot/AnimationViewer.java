package robot;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;



/**
 * Simple GUI program to show an animation of robots. Class AnimationViewer is
 * a special kind of GUI component (JPanel), and as such an instance of 
 * AnimationViewer can be added to a JFrame object. A JFrame object is a 
 * window that can be closed, minimized, and maximized. The state of an
 * AnimationViewer object comprises a list of Robots and a Timer object. An
 * AnimationViewer instance subscribes to events that are published by a Timer.
 * In response to receiving an event from the Timer, the AnimationViewer iterates 
 * through a list of Robots requesting that each Robot paints and moves itself.
 * 
 * @author Craig Sutherland
 * 
 */
@SuppressWarnings("serial")
public class AnimationViewer extends JPanel implements ActionListener {
	// Frequency in milliseconds for the Timer to generate events.
	private static final int DELAY = 20;

	// Collection of Robots to animate.
	private List<Robot> _robots;

	private Timer _timer = new Timer(DELAY, this);

	/** 
	 * Creates an AnimationViewer instance with a list of Robot objects and 
	 * starts the animation.
	 */
	public AnimationViewer() {
		_robots = new ArrayList<Robot>();

		// Populate the list of Robots.
		
		
		
		
//		// Initialise wheeled robot objects
//		_robots.add(new WheeledRobot(0, 0, 2, 3));
//		_robots.add(new WheeledRobot(10, 10, 5, 7));
//
//		// Initialise flying robot objects
//		_robots.add(new FlyingRobot(10, 0, 10, 6));
//		_robots.add(new FlyingRobot(20, 5, 5, 7, 0, 40));
//
//		// Initialise tracked robot objects
//		_robots.add(new TrackedRobot(50, 80, 5, 5, 80, 60));
//		_robots.add(new TrackedRobot(20, 40, 5, 7, 20, 30));
//
//		// Initialise dynamic wheeled robot objects
		_robots.add(new DynamicWheeledRobot(20, 30, 3, 5, 60, 84, Color.blue));
		_robots.add(new DynamicWheeledRobot(100, 90, 10, 3, 60, 85, Color.PINK));

//		// Initialise imaged robot objects
//		_robots.add(new ImagedRobot(100, 40, 5, 3, 1000, 600, "", "Dragonborn.png"));
//		_robots.add(new ImagedRobot(30, 70, -3, 5, 200, 200, "", "Snow.png"));
//		 
//
//		// Initialise carrier robot objects
		CarrierRobot two = new CarrierRobot(0, 0, 1, 1, 50, 50);
		CarrierRobot one = new CarrierRobot(0, 0, 1, 1, 200, 200);
		one.add(new DynamicWheeledRobot(0, 0, 1, 1, 100, 100));
		ImagedRobot ex = new ImagedRobot(0, 0, 5, 3, 20, 20, "", "PinkBean.png");
		one.add(new ImagedRobot(30, 70, -3, 5, 100, 100, "", "Puma.png"));
		two.add(ex);
		one.add(two);
		one.add(new FlyingRobot(100, 100, 3, 3, 30, 40));
		_robots.add(one);
		
		// Initialise text-based objects
//		ImagedRobot food = new ImagedRobot(10, 10, 1, 1, 300, 300, "Spiderman.jpg");
//		food.addText("I don't feel so good");
//		_robots.add(food);
//		TrackedRobot drink = new TrackedRobot(20, 5, 1, 1, 200, 200);
//		drink.addText("I like chocolate and mint ice cream with waffles");
//		_robots.add(drink);
		WheeledRobot bubbles = new WheeledRobot(20, 5, 3, -7, 220, 150, "hello");
		_robots.add(bubbles);
		_robots.add(new TrackedRobot(20, 40, 5, 7, 20, 30));
		
		
		
//		_robots.add(new FlyingRobot(20, 5, 1, 1, 20, 200, "blop"));
//		_robots.add(new TrackedRobot(10, 30, 1, 1, 60, 30, "yo"));
//		_robots.add(new DynamicWheeledRobot(100, 90, 1, 1, 60, 85, "lol"));
		
		
		
		
		



		// Start the animation.
		_timer.start();
	}

	/**
	 * Called by the Swing framework whenever this AnimationViewer object
	 * should be repainted. This can happen, for example, after an explicit 
	 * repaint() call or after the window that contains this AnimationViewer 
	 * object has been opened, exposed or moved.
	 * z
	 */
	public void paintComponent(Graphics g) {
		// Call inherited implementation to handle background painting.
		super.paintComponent(g);

		// Calculate bounds of animation screen area.
		int width = getSize().width;
		int height = getSize().height;

		// Create a GraphicsPainter that Robot objects will use for drawing.
		// The GraphicsPainter delegates painting to a basic Graphics object.
		Painter painter = new GraphicsPainter(g);

		// Progress the animation.
		for(Robot robot : _robots) {
			robot.paint(painter);
			robot.move(width, height);
		}
	}

	/**
	 * Notifies this AnimationViewer object of an ActionEvent. ActionEvents are
	 * received by the Timer.
	 */
	public void actionPerformed(ActionEvent e) {
		// Request that the AnimationViewer repaints itself. The call to 
		// repaint() will cause the AnimationViewer's paintComponent() method 
		// to be called.
		repaint();
	}


	/**
	 * Main program method to create an AnimationViewer object and display this
	 * within a JFrame window.
	 */
	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				JFrame frame = new JFrame("Animation viewer");
				frame.add(new AnimationViewer());

				// Set window properties.
				frame.setSize(500, 500);
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
			}
		});
	}
}
